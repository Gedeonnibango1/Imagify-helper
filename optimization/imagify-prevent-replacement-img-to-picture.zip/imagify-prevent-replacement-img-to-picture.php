<?php
/**
 * Plugin Name: Imagify | No replacemet of <img> tag with <picture> tag
 * Description: To prevent the replacement of < img> tags with < picture>, when Imagify's WebP feature is enabled.
 * Plugin URI:  {GitHub repo URL of this plugin}
 * Author:      Gedeon Nibango and Imagify Support Team
 * Author URI:  http://imagify.io/
 * License:     GNU General Public License v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Copyright SAS WP MEDIA 2020
 */

// Namespaces must be declared before any other declaration.
namespace ImagifyPlugin\Helpers\optimization\replacement;

// Standard plugin security, keep this line in place.
defined( 'ABSPATH' ) or die();

/**
 * Adds customizations once Imagify has loaded.
 * HEADS UP: If you keep the deactivation hook further down this file,
 * you will have to edit it to remove_filter() this function.
 *
 * @author Gedeon Nibango
 * 
 */

function no_replace_img_picture($allow) {

	//$allow = apply_filters( 'imagify_allow_picture_tags_for_webp', false );

	if ( ! $allow ) {
		return $allow;
	}

}

add_filter( 'imagify_allow_picture_tags_for_webp', 'no_replace_img_picture' );
